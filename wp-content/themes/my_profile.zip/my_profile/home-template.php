<?php
    /**
    * Template Name: Home Template
    */
?>
<?php get_header(); ?>

    <?php echo the_content();?>

<!--Content ends-->
<?php get_footer(); ?>