<?php get_header(); ?>
    <?php echo get_the_content(); ?> 
<?php get_footer(); ?>
