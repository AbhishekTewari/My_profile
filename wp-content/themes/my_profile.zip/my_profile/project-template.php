<?php
    /**
    * Template Name: Projects Template
    */
?>
<?php get_header(); ?>

<?php get_footer(); ?>