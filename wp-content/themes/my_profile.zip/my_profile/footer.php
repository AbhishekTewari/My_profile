    </div> <!-- main content div ends -->
        <footer>
            <p>&copy; <?php echo date('Y'); ?> All rights reserved by Abhishek Tiwari.</p>
            <?php wp_footer(); ?>
        </footer>
    </body>
</html>
