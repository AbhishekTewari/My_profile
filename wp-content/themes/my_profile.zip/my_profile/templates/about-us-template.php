<?php
    /**
    * Template Name: About Us
    */
?>
<?php get_header()?>

<?php echo do_shortcode('[contact-form-7 id="a89d1a2" title="Contact form 1"]'); ?>

<?php get_footer()?>